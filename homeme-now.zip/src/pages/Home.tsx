import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Verified, Home as HomeIcon, Search, Hammer, CreditCard, Zap, Eye, Users } from 'lucide-react';
import PropertyCard from '../components/PropertyCard';
import { motion } from 'framer-motion';

export default function Home() {
  const services = [
    {
      icon: <HomeIcon className="text-secondary" />,
      title: 'Property Management',
      desc: 'Full-service oversight including inspections, legal compliance, and strategic improvements.',
    },
    {
      icon: <Search className="text-secondary" />,
      title: 'Tenant Sourcing',
      desc: 'Rigorous multi-point screening to ensure only the most reliable residents for your home.',
    },
    {
      icon: <Hammer className="text-secondary" />,
      title: 'Maintenance',
      desc: '24/7 reactive and proactive maintenance through our network of vetted luxury contractors.',
    },
    {
      icon: <CreditCard className="text-secondary" />,
      title: 'Rent Collection',
      desc: 'Automated, secure payment processing with 100% transparency and real-time reporting.',
    },
  ];

  const properties = [
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD5O-uDbsuTo87gFoBJZZX98_uHQg-MZzvkVV8d7MpmR6SKw80AVeSXsZokAnyaKfHmFlSkAg5Q1kTc9uURtGzCTg57bGcRQPIitIBP-q-_qXQMX0Bw4XdxcoY4Jl1J0DXZEh9Bjcg-yO2PufJEqMFWGwbluspU-NcLXFDPkhQZR7ie4scCaMbBBHVYKnn5K6JRhTyp-Ghj8fK9v-RJerUdHCuEhxbVLgxqopiLwADl-BuNTifGTcAot7VZJKrT91rTUC_k8b0LHvI',
      title: 'The Obsidian Villa',
      price: '$8,500/mo',
      location: 'Beverly Hills, CA',
      description: 'An architectural masterpiece featuring floor-to-ceiling glass and panoramic canyon views.',
      tag: 'Premium Listing',
    },
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBVYVD1mCw3mhrkWah2x5-Vah1IidTEWJUVMcGMKvnkRwTFXVvPSjhCA5ybbvJQqTLjVVdQhRwAu7Q6sLw3MMV8ttgYQfFe1xjOP4Mj45nvY8_0FmaAWspB8YEVF_ZAh7hz_7--_aMmbAHLnHQ9aqH0xj0tmhXNSmsV6420IIvVC2-xaW2zIpPLPL8AvS3egYMD0Cxe-W224hX50buQqgs16FS52MYaazCCQF31P5-9gDOcqSm1Kgka-rOd2IXP1Je3TZPCvRznwq4',
      title: 'Skyline Loft',
      price: '$12,000/mo',
      location: 'Manhattan, NY',
      description: 'Penthouse living redefined with private elevator access and 360-degree skyline views.',
      tag: 'New Arrival',
    },
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCqH9ew_HYyGIvh5WreKkSRuAvFvwHZLGIdrP_SbCYq_ZV_5pkG7aN2fCyYXUZoaKZzkzU4xk1OkwV04w-yffGhe2rk2E_58WFE81XzdG6cAPVqqLKmKKbKIFcZw8T50t4IudHcrpb515UgTKkieilihrV4a9S9NKJ0saVZLGJsQMtuimexedWjtre5AnxhctQFWr0wbLd5s3n7CU4STeTrLD5SzAgfEO8NEdlLm0P6SxTzpuhAq5Fx0P2-E1q15ye_5OaXa9VyG14',
      title: 'Azure Retreat',
      price: '$6,200/mo',
      location: 'Miami Beach, FL',
      description: 'Coastal elegance meets smart home technology in this recently renovated waterfront oasis.',
      tag: 'Fully Managed',
    },
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-24 md:pt-32">
        <div className="absolute inset-0 z-0">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuC2gg6Q1l3QI8coQlLTX6rptbQPPnaXOjqQuTkpeQLbk6SiN9xfwWbRxC60d7WiaDdDnt5c1_uNb9UEPgiWy7frhNM9OFTnjnkxg8tPeci7SYNwGrOx7PmVWHR1uY0DJ99Uh_ZlOQeEmmXZgTufYzSObMWtwNdBI_52CdiClgxpOf0oIQ_ANm0tIi0W5q2qdN5MKeyN9MI2BDioMhwwBRh-OKvs2WktfGYse33oneTVmyDCk5Zq7Hq0YYSZ2Gcil14x1zPQuNlRrs4"
            alt="Luxury property"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/90 via-primary/40 to-transparent dark:from-slate-950/95 dark:via-slate-950/60 dark:to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-8 w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <h1 className="text-5xl md:text-7xl font-headline font-extrabold text-white tracking-tight leading-[1.1] mb-6 dark:font-serif dark:italic">
              Stress-Free Property Management Starts Here
            </h1>
            <p className="text-xl text-slate-300 mb-10 leading-relaxed font-light">
              Experience the gold standard in asset preservation. We handle the logistics, you enjoy the returns. High-end management for discerning landlords.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/contact"
                className="bg-secondary-fixed text-primary px-8 py-4 rounded-lg font-bold text-lg hover:brightness-110 transition-all text-center editorial-shadow"
              >
                Get Started
              </Link>
              <Link
                to="/properties"
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white/20 transition-all text-center"
              >
                View Properties
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Hero Floating Card */}
        <div className="absolute bottom-12 right-12 hidden lg:block max-w-sm">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl p-6 rounded-xl editorial-shadow border border-slate-200/20"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-secondary-container flex items-center justify-center">
                <Verified className="text-on-secondary-container" size={24} />
              </div>
              <div>
                <p className="font-headline font-bold text-primary dark:text-white">Certified Premium</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Over 500+ Luxury Estates Managed</p>
              </div>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 italic">"The most seamless transition I've ever experienced with my portfolio."</p>
          </motion.div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-12 bg-slate-50 dark:bg-slate-900/50 border-y border-slate-100 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex flex-wrap justify-center items-center gap-12 opacity-60 grayscale hover:grayscale-0 transition-all duration-700">
            <div className="flex items-center gap-2 font-headline font-black text-xl dark:text-white">ESTATE TRUST</div>
            <div className="flex items-center gap-2 font-headline font-black text-xl dark:text-white">SAFEGUARD</div>
            <div className="flex items-center gap-2 font-headline font-black text-xl dark:text-white">NATIONAL BANK</div>
            <div className="flex items-center gap-2 font-headline font-black text-xl dark:text-white">RENTSHIELD</div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-24 bg-white dark:bg-slate-950 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <span className="text-secondary dark:text-secondary-fixed font-bold tracking-widest uppercase text-sm block mb-4">Our Services</span>
            <h2 className="text-4xl md:text-5xl font-headline font-bold text-primary dark:text-white leading-tight dark:font-serif">Elite Care for Every Asset</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -8 }}
                className="bg-slate-50 dark:bg-slate-900 p-8 rounded-2xl editorial-shadow transition-colors group"
              >
                <div className="w-14 h-14 rounded-xl bg-secondary-fixed/30 flex items-center justify-center mb-6 group-hover:bg-secondary-fixed transition-colors">
                  {service.icon}
                </div>
                <h3 className="text-xl font-headline font-bold text-primary dark:text-white mb-3">{service.title}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-24 bg-slate-50 dark:bg-slate-900/30 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-12">
            <div>
              <span className="text-secondary dark:text-secondary-fixed font-bold tracking-widest uppercase text-sm block mb-4">Portfolio Highlights</span>
              <h2 className="text-4xl font-headline font-bold text-primary dark:text-white dark:font-serif">Featured Residences</h2>
            </div>
            <Link to="/properties" className="hidden md:flex items-center gap-2 text-primary dark:text-secondary-fixed font-bold hover:gap-4 transition-all">
              View All Listings <ArrowRight size={20} />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {properties.map((prop, i) => (
              <PropertyCard key={i} image={prop.image} title={prop.title} price={prop.price} location={prop.location} description={prop.description} tag={prop.tag} />
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 px-8 overflow-hidden bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-20 items-center">
          <div className="lg:w-1/2">
            <span className="text-secondary dark:text-secondary-fixed font-bold tracking-widest uppercase text-sm block mb-4">The Advantage</span>
            <h2 className="text-4xl md:text-5xl font-headline font-bold text-primary dark:text-white leading-tight mb-8 dark:font-serif">Management Tailored to Excellence</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="flex flex-col gap-3">
                <Verified className="text-secondary dark:text-secondary-fixed" size={32} />
                <h4 className="font-headline font-bold text-primary dark:text-white">Unmatched Reliability</h4>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Consistent performance and zero-tolerance for missed details.</p>
              </div>
              <div className="flex flex-col gap-3">
                <Zap className="text-secondary dark:text-secondary-fixed" size={32} />
                <h4 className="font-headline font-bold text-primary dark:text-white">Fast Turnaround</h4>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Leasing vacancies in 14 days or less on average.</p>
              </div>
              <div className="flex flex-col gap-3">
                <Eye className="text-secondary dark:text-secondary-fixed" size={32} />
                <h4 className="font-headline font-bold text-primary dark:text-white">Radical Transparency</h4>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Real-time owner portal with 24/7 financial tracking.</p>
              </div>
              <div className="flex flex-col gap-3">
                <Users className="text-secondary dark:text-secondary-fixed" size={32} />
                <h4 className="font-headline font-bold text-primary dark:text-white">Expert Team</h4>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Local specialists with deep market intelligence.</p>
              </div>
            </div>
          </div>
          <div className="lg:w-1/2 relative">
            <div className="relative z-10 rounded-3xl overflow-hidden editorial-shadow">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuB0o9-kN8NkeahdoAcnEF605_IZOxMmbtxweQtHXFY0LF1h5EgjXYzl9zNuxnJZ3uj9KxqUvvbe34ZjFQW6vDWr648xsBEEe_doTvX1jOgEOvJiT2JkNYPcn8dmK9tLVwErUuT5LypY6Y4eERJQmSU_d3eTzRocPsHJXeTzsuEYw5KlFxud7JpNI2SCbE_jBt9KYw3tT_c9yQbCZlQipPxfgx2n_5k3VvBaba8EDmyTdudLl3kildi7TAmmU57Q88hv1BHk8NxWvBY"
                alt="Our Team"
                className="w-full h-auto"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-secondary-fixed opacity-20 rounded-full blur-3xl -z-10"></div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-primary dark:bg-slate-900 text-white px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-headline font-bold mb-4 dark:font-serif dark:italic">Client Voices</h2>
            <p className="text-slate-400 max-w-xl mx-auto">Trusted by international investors and local families alike.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
             {[
               {
                 name: 'Julian Sterling',
                 role: 'Multi-Property Owner',
                 text: "Switching to HomeMe Now was the best decision for my portfolio. Their attention to detail and proactive maintenance saved me thousands this year.",
                 img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB-cwTUeNFBeSXrfQ0wvjEFb2xoMeuA45X3cuEKDSR6R6rmt2k_aU87phHBm9fJ6opW-kflfCWjl84iPXdGkBClYq_6LOJsrgd-U4jHeE3_h2c2D-_LaqIkIMnqKGduo4qIHmx-W5CPMtIOsG1ETRakdWgC-JU5xp-ZnIV_7DcVz7-L3GWp4-vd9MOEg2RjyIwN2MzABb5qBvSqih2vKLd4AE7nAKSwHwMbdCQh_8bkOtrds4tRNNlt1G-Rd9PSlm3GX3qV6a3UWmE'
               },
               {
                 name: 'Elena Vance',
                 role: 'Real Estate Investor',
                 text: "The communication is flawless. I never have to chase for updates; I just log into my dashboard and everything is right there. Highly recommended.",
                 img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAcHyU1ePYQI7YjpMMsqcPKYjh1EBJ_6_Di5FQOdRbwi8qhFuFSbS30dUihP2msy-gWGWAaVO2JDZQ8AdKoikSDzmw0ya4V-1lscv9aLv7rm_5uUt58A_CRVW3h9yjgi69nqLGFjqe_I7Lx021aBM9lhEBaGyhvpiEHH-m2lv5DQCkfZJBEJ2FhmCeyxFwxq8E6is3L5mNyHD6bddhi70-1_YA-FGspn_bbn8jEg8YxXAOMAJL3W7YF0RB1BAXQpKdCRpTYzZrvNAg'
               },
               {
                 name: 'Marcus Thorne',
                 role: 'Developer',
                 text: "They handled a difficult tenant situation with such professionalism and legal expertise. I felt completely protected throughout the whole process.",
                 img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBE7D0bS2891rCvJmZlCqpIsZwwsbsoCjbOF2MiAfe5YPH47d6iU1umYCFLHwTJhMWW1j7jJL1B9vYSgPLtEctOkUwSgDqVvmcx9R50vrB2LTgvxtM4qI1VgM8TgPKpRi54IMeFne0q3bLM40E78a1tuEsm5brEmt67_aRCECZdn37ot_zEO1LTC2kIT3QAAuqM8uxaSEIs8pMO8CxdoMIo5HwysDG4v4azCXpZ7N0h3635ca22XTxr3zMcXaercMoXwq60B5oRqlE'
               }
             ].map((t, i) => (
               <div key={i} className="bg-white/5 border border-white/10 p-8 rounded-2xl backdrop-blur-sm">
                 <div className="flex gap-1 text-secondary-fixed mb-6">
                   {[...Array(5)].map((_, j) => <Verified key={j} size={16} fill="currentColor" />)}
                 </div>
                 <p className="text-lg italic mb-8 leading-relaxed">"{t.text}"</p>
                 <div className="flex items-center gap-4">
                   <div className="w-12 h-12 rounded-full overflow-hidden">
                     <img src={t.img} alt={t.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                   </div>
                   <div>
                     <p className="font-bold">{t.name}</p>
                     <p className="text-sm text-slate-400">{t.role}</p>
                   </div>
                 </div>
               </div>
             ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-8 bg-white dark:bg-slate-950">
        <div className="max-w-5xl mx-auto rounded-[2.5rem] bg-gradient-to-br from-secondary-fixed to-secondary-container p-12 md:p-20 text-center editorial-shadow relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
          <div className="relative z-10">
            <h2 className="text-4xl md:text-5xl font-headline font-extrabold text-primary mb-6 dark:font-serif">Ready for Peace of Mind?</h2>
            <p className="text-xl text-primary/80 mb-10 max-w-2xl mx-auto">Join the elite circle of property owners who trust HomeMe Now for their asset management.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/contact"
                className="bg-primary text-white px-10 py-5 rounded-xl font-bold text-lg hover:scale-105 transition-transform editorial-shadow"
              >
                Schedule a Consultation
              </Link>
              <Link
                to="/contact"
                className="bg-transparent border-2 border-primary text-primary px-10 py-5 rounded-xl font-bold text-lg hover:bg-primary/5 transition-colors"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
