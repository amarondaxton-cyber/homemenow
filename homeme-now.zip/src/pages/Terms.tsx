export default function Terms() {
  return (
    <div className="pt-32 pb-24 px-6 max-w-4xl mx-auto min-h-screen">
      <h1 className="text-4xl md:text-5xl font-extrabold font-headline text-primary dark:text-white mb-12 dark:font-serif dark:italic">Terms of Service</h1>
      <div className="prose prose-slate dark:prose-invert max-w-none space-y-8 text-slate-600 dark:text-slate-400 leading-relaxed">
        <section>
          <h2 className="text-2xl font-bold text-primary dark:text-white mb-4">1. Agreement to Terms</h2>
          <p>
            By accessing or using the HomeMe Now website, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-bold text-primary dark:text-white mb-4">2. Use License</h2>
          <p>
            Permission is granted to temporarily download one copy of the materials (information or software) on HomeMe Now's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-bold text-primary dark:text-white mb-4">3. Disclaimer</h2>
          <p>
            The materials on HomeMe Now's website are provided on an 'as is' basis. HomeMe Now makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-bold text-primary dark:text-white mb-4">4. Limitations</h2>
          <p>
            In no event shall HomeMe Now or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on HomeMe Now's website, even if HomeMe Now or a HomeMe Now authorized representative has been notified orally or in writing of the possibility of such damage.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-bold text-primary dark:text-white mb-4">5. Governing Law</h2>
          <p>
            These terms and conditions are governed by and construed in accordance with the laws of New York and you irrevocably submit to the exclusive jurisdiction of the courts in that State or location.
          </p>
        </section>
      </div>
    </div>
  );
}
