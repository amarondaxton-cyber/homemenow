import { useState } from 'react';
import { Search, Filter, MapPin } from 'lucide-react';
import PropertyCard from '../components/PropertyCard';

export default function Properties() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'Houses', 'Apartments', 'Villas', 'Commercial'];

  const allProperties = [
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD5O-uDbsuTo87gFoBJZZX98_uHQg-MZzvkVV8d7MpmR6SKw80AVeSXsZokAnyaKfHmFlSkAg5Q1kTc9uURtGzCTg57bGcRQPIitIBP-q-_qXQMX0Bw4XdxcoY4Jl1J0DXZEh9Bjcg-yO2PufJEqMFWGwbluspU-NcLXFDPkhQZR7ie4scCaMbBBHVYKnn5K6JRhTyp-Ghj8fK9v-RJerUdHCuEhxbVLgxqopiLwADl-BuNTifGTcAot7VZJKrT91rTUC_k8b0LHvI',
      title: 'The Obsidian Villa',
      price: '$8,500/mo',
      location: 'Beverly Hills, CA',
      description: 'An architectural masterpiece featuring floor-to-ceiling glass and panoramic canyon views.',
      tag: 'Premium Listing',
      type: 'Villas',
      beds: 5,
      baths: 6,
      sqft: '6,200',
    },
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBVYVD1mCw3mhrkWah2x5-Vah1IidTEWJUVMcGMKvnkRwTFXVvPSjhCA5ybbvJQqTLjVVdQhRwAu7Q6sLw3MMV8ttgYQfFe1xjOP4Mj45nvY8_0FmaAWspB8YEVF_ZAh7hz_7--_aMmbAHLnHQ9aqH0xj0tmhXNSmsV6420IIvVC2-xaW2zIpPLPL8AvS3egYMD0Cxe-W224hX50buQqgs16FS52MYaazCCQF31P5-9gDOcqSm1Kgka-rOd2IXP1Je3TZPCvRznwq4',
      title: 'Skyline Loft',
      price: '$12,000/mo',
      location: 'Manhattan, NY',
      description: 'Penthouse living redefined with private elevator access and 360-degree skyline views.',
      tag: 'New Arrival',
      type: 'Apartments',
      beds: 3,
      baths: 3,
      sqft: '3,500',
    },
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCqH9ew_HYyGIvh5WreKkSRuAvFvwHZLGIdrP_SbCYq_ZV_5pkG7aN2fCyYXUZoaKZzkzU4xk1OkwV04w-yffGhe2rk2E_58WFE81XzdG6cAPVqqLKmKKbKIFcZw8T50t4IudHcrpb515UgTKkieilihrV4a9S9NKJ0saVZLGJsQMtuimexedWjtre5AnxhctQFWr0wbLd5s3n7CU4STeTrLD5SzAgfEO8NEdlLm0P6SxTzpuhAq5Fx0P2-E1q15ye_5OaXa9VyG14',
      title: 'Azure Retreat',
      price: '$6,200/mo',
      location: 'Miami Beach, FL',
      description: 'Coastal elegance meets smart home technology in this recently renovated waterfront oasis.',
      tag: 'Fully Managed',
      type: 'Houses',
      beds: 4,
      baths: 4,
      sqft: '4,100',
    },
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB0o9-kN8NkeahdoAcnEF605_IZOxMmbtxweQtHXFY0LF1h5EgjXYzl9zNuxnJZ3uj9KxqUvvbe34ZjFQW6vDWr648xsBEEe_doTvX1jOgEOvJiT2JkNYPcn8dmK9tLVwErUuT5LypY6Y4eERJQmSU_d3eTzRocPsHJXeTzsuEYw5KlFxud7JpNI2SCbE_jBt9KYw3tT_c9yQbCZlQipPxfgx2n_5k3VvBaba8EDmyTdudLl3kildi7TAmmU57Q88hv1BHk8NxWvBY',
      title: 'The Modernist',
      price: '$5,400/mo',
      location: 'Austin, TX',
      description: 'Minimalist design with maximum impact. A perfect blend of concrete, steel, and warm wood.',
      tag: 'Hot Deal',
      type: 'Houses',
      beds: 3,
      baths: 2,
      sqft: '2,800',
    },
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC2gg6Q1l3QI8coQlLTX6rptbQPPnaXOjqQuTkpeQLbk6SiN9xfwWbRxC60d7WiaDdDnt5c1_uNb9UEPgiWy7frhNM9OFTnjnkxg8tPeci7SYNwGrOx7PmVWHR1uY0DJ99Uh_ZlOQeEmmXZgTufYzSObMWtwNdBI_52CdiClgxpOf0oIQ_ANm0tIi0W5q2qdN5MKeyN9MI2BDioMhwwBRh-OKvs2WktfGYse33oneTVmyDCk5Zq7Hq0YYSZ2Gcil14x1zPQuNlRrs4',
      title: 'Heritage Manor',
      price: '$15,000/mo',
      location: 'Greenwich, CT',
      description: 'A historic estate meticulously restored for modern luxury living. 12 acres of private grounds.',
      tag: 'Exclusive',
      type: 'Villas',
      beds: 8,
      baths: 10,
      sqft: '12,500',
    },
    {
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAYZwU_Zd8Z4QtC74lhep-E26Ig29VDe4PWVFDscqwkNN4vOmxw-JGBhJs2gyP2jAncS-8nwmJw58Os8O8-udno7boOUuJN2PvYPwalOLtCfb2VQwK-AqM3Uf2chOsivlppx1dMqMlHN3JBAJMDSlVaPmWmZ687ukKrRYRWl0Sf8B0JIDmIhb9Jvvw_-d6ZMk3bCojbt_l4qewSdy6UZbedl2xQHVgdv6iJED_FDr7inziUvMfhG9loPRVUftBTCHHKf1JjOS401LU',
      title: 'Glass House',
      price: '$9,800/mo',
      location: 'Malibu, CA',
      description: 'Perched on a cliffside, this home offers breathtaking ocean views from every single room.',
      tag: 'Oceanfront',
      type: 'Villas',
      beds: 4,
      baths: 5,
      sqft: '5,400',
    },
  ];

  const filteredProperties = allProperties.filter((p) => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = activeFilter === 'All' || p.type === activeFilter;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="pt-20 min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      <header className="py-16 px-6 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-12">
          <div>
            <h1 className="text-5xl font-extrabold font-headline text-primary dark:text-white mb-4 dark:font-serif dark:italic">
              Our Portfolio
            </h1>
            <p className="text-lg text-slate-500 dark:text-slate-400 max-w-xl">
              Curated residences managed with uncompromising standards. Discover your next home.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="relative flex-grow md:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="text"
                placeholder="Search location or title..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-secondary transition-all dark:text-white"
              />
            </div>
            <button className="flex items-center justify-center gap-2 px-6 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl font-bold text-primary dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800 transition-all">
              <Filter size={18} />
              Filters
            </button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-3 mb-12">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${
                activeFilter === filter
                  ? 'bg-secondary dark:bg-secondary-fixed text-white dark:text-primary shadow-lg'
                  : 'bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-800 hover:border-secondary dark:hover:border-secondary-fixed'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Property Grid */}
        {filteredProperties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredProperties.map((prop, i) => (
              <PropertyCard 
                key={i} 
                image={prop.image} 
                title={prop.title} 
                price={prop.price} 
                location={prop.location} 
                description={prop.description} 
                tag={prop.tag}
                beds={prop.beds}
                baths={prop.baths}
                sqft={prop.sqft}
              />
            ))}
          </div>
        ) : (
          <div className="py-24 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 dark:bg-slate-900 text-slate-400 mb-6">
              <Search size={40} />
            </div>
            <h3 className="text-2xl font-bold text-primary dark:text-white mb-2">No properties found</h3>
            <p className="text-slate-500 dark:text-slate-400">Try adjusting your search or filters.</p>
          </div>
        )}
      </header>

      {/* Featured Banner */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto rounded-[3rem] bg-primary dark:bg-slate-900 p-12 md:p-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuC2gg6Q1l3QI8coQlLTX6rptbQPPnaXOjqQuTkpeQLbk6SiN9xfwWbRxC60d7WiaDdDnt5c1_uNb9UEPgiWy7frhNM9OFTnjnkxg8tPeci7SYNwGrOx7PmVWHR1uY0DJ99Uh_ZlOQeEmmXZgTufYzSObMWtwNdBI_52CdiClgxpOf0oIQ_ANm0tIi0W5q2qdN5MKeyN9MI2BDioMhwwBRh-OKvs2WktfGYse33oneTVmyDCk5Zq7Hq0YYSZ2Gcil14x1zPQuNlRrs4"
              alt="Luxury background"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="relative z-10 max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-extrabold text-white font-headline mb-6 dark:font-serif dark:italic">Looking for something specific?</h2>
            <p className="text-xl text-slate-300 mb-10 leading-relaxed">
              Our concierge team can source off-market properties tailored to your exact requirements. Let us find your perfect match.
            </p>
            <button className="bg-secondary-fixed text-primary px-10 py-4 rounded-xl font-bold text-lg hover:brightness-110 transition-all shadow-2xl">
              Contact Concierge
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
