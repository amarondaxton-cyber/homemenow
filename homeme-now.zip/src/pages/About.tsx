import { Verified, Target, Heart, ShieldCheck, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function About() {
  const values = [
    {
      icon: <Verified className="text-secondary" />,
      title: 'Precision',
      desc: 'We believe that excellence lies in the details. From maintenance logs to financial reporting, we operate with surgical precision.',
    },
    {
      icon: <Target className="text-secondary" />,
      title: 'Integrity',
      desc: 'Transparency is our foundation. We provide honest, clear communication to both owners and tenants at every touchpoint.',
    },
    {
      icon: <Heart className="text-secondary" />,
      title: 'Empathy',
      desc: 'Property management is about people. We treat every home as if it were our own and every tenant with the respect they deserve.',
    },
    {
      icon: <ShieldCheck className="text-secondary" />,
      title: 'Reliability',
      desc: 'When we say it\'s handled, it\'s handled. Our clients trust us to be their eyes and ears on the ground, 24/7.',
    },
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-24 px-6 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-20">
          <div className="lg:w-1/2">
            <span className="text-secondary dark:text-secondary-fixed font-bold tracking-widest uppercase text-sm block mb-4">Our Story</span>
            <h1 className="text-5xl md:text-7xl font-extrabold font-headline text-primary dark:text-white leading-[1.1] mb-8 dark:font-serif dark:italic">
              Redefining the Standard of Care
            </h1>
            <p className="text-xl text-slate-600 dark:text-slate-400 leading-relaxed mb-8 font-light">
              Founded on the principle that property management should be a seamless, high-end experience, HomeMe Now has grown from a boutique firm to a leading name in premium asset management.
            </p>
            <p className="text-lg text-slate-500 dark:text-slate-500 leading-relaxed mb-10">
              We saw a gap in the market—a need for management that combined the efficiency of modern technology with the personal touch of a luxury concierge. Today, we manage over $1.2B in real estate assets with the same dedication we had on day one.
            </p>
            <div className="flex items-center gap-8">
              <div>
                <p className="text-4xl font-black text-primary dark:text-white font-headline">12+</p>
                <p className="text-sm text-slate-500 uppercase tracking-widest font-bold">Years Experience</p>
              </div>
              <div className="w-px h-12 bg-slate-200 dark:border-slate-800"></div>
              <div>
                <p className="text-4xl font-black text-primary dark:text-white font-headline">500+</p>
                <p className="text-sm text-slate-500 uppercase tracking-widest font-bold">Properties Managed</p>
              </div>
            </div>
          </div>
          <div className="lg:w-1/2 relative">
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBVYVD1mCw3mhrkWah2x5-Vah1IidTEWJUVMcGMKvnkRwTFXVvPSjhCA5ybbvJQqTLjVVdQhRwAu7Q6sLw3MMV8ttgYQfFe1xjOP4Mj45nvY8_0FmaAWspB8YEVF_ZAh7hz_7--_aMmbAHLnHQ9aqH0xj0tmhXNSmsV6420IIvVC2-xaW2zIpPLPL8AvS3egYMD0Cxe-W224hX50buQqgs16FS52MYaazCCQF31P5-9gDOcqSm1Kgka-rOd2IXP1Je3TZPCvRznwq4"
                alt="Modern building"
                className="rounded-2xl h-80 w-full object-cover editorial-shadow"
                referrerPolicy="no-referrer"
              />
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCqH9ew_HYyGIvh5WreKkSRuAvFvwHZLGIdrP_SbCYq_ZV_5pkG7aN2fCyYXUZoaKZzkzU4xk1OkwV04w-yffGhe2rk2E_58WFE81XzdG6cAPVqqLKmKKbKIFcZw8T50t4IudHcrpb515UgTKkieilihrV4a9S9NKJ0saVZLGJsQMtuimexedWjtre5AnxhctQFWr0wbLd5s3n7CU4STeTrLD5SzAgfEO8NEdlLm0P6SxTzpuhAq5Fx0P2-E1q15ye_5OaXa9VyG14"
                alt="Interior"
                className="rounded-2xl h-80 w-full object-cover mt-12 editorial-shadow"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-secondary-fixed/10 blur-3xl rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-24 bg-slate-50 dark:bg-slate-900/50 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <span className="text-secondary dark:text-secondary-fixed font-bold tracking-widest uppercase text-sm block mb-4">Our DNA</span>
            <h2 className="text-4xl md:text-5xl font-bold font-headline text-primary dark:text-white dark:font-serif">The Values That Drive Us</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {values.map((v, i) => (
              <div key={i} className="flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full bg-white dark:bg-slate-800 flex items-center justify-center mb-8 editorial-shadow">
                  {v.icon}
                </div>
                <h3 className="text-2xl font-bold font-headline text-primary dark:text-white mb-4">{v.title}</h3>
                <p className="text-slate-500 dark:text-slate-400 leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 bg-white dark:bg-slate-950 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <div className="max-w-2xl">
              <span className="text-secondary dark:text-secondary-fixed font-bold tracking-widest uppercase text-sm block mb-4">The Experts</span>
              <h2 className="text-4xl md:text-5xl font-bold font-headline text-primary dark:text-white dark:font-serif">Led by Visionaries</h2>
              <p className="text-lg text-slate-500 dark:text-slate-400 mt-6">Our leadership team brings decades of combined experience in luxury real estate, finance, and hospitality.</p>
            </div>
            <Link to="/contact" className="bg-primary dark:bg-secondary-fixed text-white dark:text-primary px-8 py-4 rounded-xl font-bold hover:scale-105 transition-transform">
              Join Our Team
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                name: 'Alexander Thorne',
                role: 'Founder & CEO',
                img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBE7D0bS2891rCvJmZlCqpIsZwwsbsoCjbOF2MiAfe5YPH47d6iU1umYCFLHwTJhMWW1j7jJL1B9vYSgPLtEctOkUwSgDqVvmcx9R50vrB2LTgvxtM4qI1VgM8TgPKpRi54IMeFne0q3bLM40E78a1tuEsm5brEmt67_aRCECZdn37ot_zEO1LTC2kIT3QAAuqM8uxaSEIs8pMO8CxdoMIo5HwysDG4v4azCXpZ7N0h3635ca22XTxr3zMcXaercMoXwq60B5oRqlE'
              },
              {
                name: 'Sarah Jenkins',
                role: 'Director of Operations',
                img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAcHyU1ePYQI7YjpMMsqcPKYjh1EBJ_6_Di5FQOdRbwi8qhFuFSbS30dUihP2msy-gWGWAaVO2JDZQ8AdKoikSDzmw0ya4V-1lscv9aLv7rm_5uUt58A_CRVW3h9yjgi69nqLGFjqe_I7Lx021aBM9lhEBaGyhvpiEHH-m2lv5DQCkfZJBEJ2FhmCeyxFwxq8E6is3L5mNyHD6bddhi70-1_YA-FGspn_bbn8jEg8YxXAOMAJL3W7YF0RB1BAXQpKdCRpTYzZrvNAg'
              },
              {
                name: 'Michael Chen',
                role: 'Head of Asset Management',
                img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB-cwTUeNFBeSXrfQ0wvjEFb2xoMeuA45X3cuEKDSR6R6rmt2k_aU87phHBm9fJ6opW-kflfCWjl84iPXdGkBClYq_6LOJsrgd-U4jHeE3_h2c2D-_LaqIkIMnqKGduo4qIHmx-W5CPMtIOsG1ETRakdWgC-JU5xp-ZnIV_7DcVz7-L3GWp4-vd9MOEg2RjyIwN2MzABb5qBvSqih2vKLd4AE7nAKSwHwMbdCQh_8bkOtrds4tRNNlt1G-Rd9PSlm3GX3qV6a3UWmE'
              }
            ].map((member, i) => (
              <div key={i} className="group">
                <div className="relative h-[400px] rounded-2xl overflow-hidden mb-6 editorial-shadow">
                  <img
                    src={member.img}
                    alt={member.name}
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <h4 className="text-2xl font-bold font-headline text-primary dark:text-white">{member.name}</h4>
                <p className="text-secondary dark:text-secondary-fixed font-bold uppercase tracking-widest text-xs mt-1">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
