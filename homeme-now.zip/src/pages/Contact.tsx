import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageCircle, Clock } from 'lucide-react';

export default function Contact() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'Property Management',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate submission
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <div className="pt-20 min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Contact Info */}
          <div>
            <span className="text-secondary dark:text-secondary-fixed font-bold tracking-widest uppercase text-sm block mb-4">Get in Touch</span>
            <h1 className="text-5xl md:text-7xl font-extrabold font-headline text-primary dark:text-white leading-[1.1] mb-8 dark:font-serif dark:italic">
              Let's Start a Conversation
            </h1>
            <p className="text-xl text-slate-600 dark:text-slate-400 leading-relaxed mb-12 font-light">
              Whether you're looking to transition your portfolio or just have a few questions about our process, our team is ready to assist.
            </p>

            <div className="space-y-8">
              <div className="flex items-center gap-6 group">
                <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-900 flex items-center justify-center editorial-shadow group-hover:bg-secondary-fixed transition-colors">
                  <Mail className="text-secondary dark:text-secondary-fixed group-hover:text-primary" size={24} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Email Us</p>
                  <p className="text-lg font-bold text-primary dark:text-white">concierge@homemenow.com</p>
                </div>
              </div>

              <div className="flex items-center gap-6 group">
                <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-900 flex items-center justify-center editorial-shadow group-hover:bg-secondary-fixed transition-colors">
                  <Phone className="text-secondary dark:text-secondary-fixed group-hover:text-primary" size={24} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Call Us</p>
                  <p className="text-lg font-bold text-primary dark:text-white">+1 (234) 567-8901</p>
                </div>
              </div>

              <div className="flex items-center gap-6 group">
                <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-900 flex items-center justify-center editorial-shadow group-hover:bg-secondary-fixed transition-colors">
                  <MapPin className="text-secondary dark:text-secondary-fixed group-hover:text-primary" size={24} />
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Visit Us</p>
                  <p className="text-lg font-bold text-primary dark:text-white">725 5th Ave, New York, NY 10022</p>
                </div>
              </div>
            </div>

            <div className="mt-16 p-8 rounded-2xl bg-secondary-fixed/10 border border-secondary-fixed/20">
              <div className="flex items-center gap-4 mb-4">
                <Clock className="text-secondary dark:text-secondary-fixed" size={20} />
                <h4 className="font-bold text-primary dark:text-white">Response Time</h4>
              </div>
              <p className="text-slate-600 dark:text-slate-400 text-sm">We typically respond to all inquiries within 2 business hours. For existing clients, our 24/7 emergency line is always available.</p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[2.5rem] editorial-shadow border border-slate-100 dark:border-slate-800">
            {isSubmitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-20">
                <div className="w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 flex items-center justify-center mb-6">
                  <Send size={40} />
                </div>
                <h2 className="text-3xl font-bold text-primary dark:text-white mb-4">Message Sent!</h2>
                <p className="text-slate-500 dark:text-slate-400 max-w-sm">Thank you for reaching out. One of our experts will be in touch shortly.</p>
                <button
                  onClick={() => setIsSubmitted(false)}
                  className="mt-8 text-secondary dark:text-secondary-fixed font-bold hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Full Name</label>
                    <input
                      required
                      type="text"
                      className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-secondary transition-all dark:text-white"
                      placeholder="John Doe"
                      value={formState.name}
                      onChange={(e) => setFormState({...formState, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Email Address</label>
                    <input
                      required
                      type="email"
                      className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-secondary transition-all dark:text-white"
                      placeholder="john@example.com"
                      value={formState.email}
                      onChange={(e) => setFormState({...formState, email: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Phone Number</label>
                    <input
                      type="tel"
                      className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-secondary transition-all dark:text-white"
                      placeholder="+1 (555) 000-0000"
                      value={formState.phone}
                      onChange={(e) => setFormState({...formState, phone: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Subject</label>
                    <select
                      className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-secondary transition-all dark:text-white appearance-none"
                      value={formState.subject}
                      onChange={(e) => setFormState({...formState, subject: e.target.value})}
                    >
                      <option>Property Management</option>
                      <option>Tenant Inquiry</option>
                      <option>Maintenance Request</option>
                      <option>Other</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Your Message</label>
                  <textarea
                    required
                    rows={5}
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-secondary transition-all dark:text-white resize-none"
                    placeholder="How can we help you?"
                    value={formState.message}
                    onChange={(e) => setFormState({...formState, message: e.target.value})}
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-primary dark:bg-secondary-fixed text-white dark:text-primary py-5 rounded-xl font-bold text-lg hover:brightness-110 transition-all shadow-xl flex items-center justify-center gap-3"
                >
                  Send Message
                  <Send size={20} />
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Map Placeholder */}
      <section className="h-[400px] w-full bg-slate-200 dark:bg-slate-800 relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
           <div className="text-center">
             <MapPin className="text-slate-400 mx-auto mb-4" size={48} />
             <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">Interactive Map Coming Soon</p>
           </div>
        </div>
        {/* Decorative overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-50/50 to-transparent dark:from-slate-950/50"></div>
      </section>
    </div>
  );
}
