import React from 'react';
import { Verified, Search, CreditCard, Hammer, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Services() {
  const services = [
    {
      title: 'Property Management',
      icon: <Verified size={32} />,
      desc: 'Our full-spectrum management service treats your property like a premium investment. We handle the complexities so you can enjoy the rewards of ownership without the stress.',
      features: [
        'Strategic asset positioning and marketing',
        'Comprehensive financial reporting and analytics',
        'Legal compliance and risk mitigation',
      ],
      img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC929GBxVsBzkMQkoDlbt3e_l3HHkgOWZvafQLEzJn9r7JB2HLRMFn16Lj9rTUwg5OrUabSu4w9JGhYq5k_H3cnYmN3iTYHiJZ7cneLYl1UgneHJW9_UPAl-nhyO9NL4_8YIRI9bAIk2HOwp01t2yX4MuAEwf9ZtK9yQwMF5b47OcHxU1RImOfN-qVGuLnKZcRxILi8OiQraOuAwBazyQENdp8WjwEf_MADq9UEsKdADeoOaRojyKYhzhMATh2BcM8WfMTYm0Gy34A',
      color: 'bg-secondary-fixed',
    },
    {
      title: 'Tenant Screening',
      icon: <Search size={32} />,
      desc: 'We don\'t just find tenants; we curate a community of reliable residents through a rigorous, multi-layered vetting process that ensures long-term stability.',
      features: [
        'Comprehensive credit and background verification',
        'Income stability and employment auditing',
        'Previous landlord reference investigations',
      ],
      img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCf2CqoNGsiWQ32HWy_MX4JTLJRw3c180mxIgJnXKNEPsPVVw3yW9fiaFCm1wuD9ITLa-rW1MNJP59g0CFO8oPolEfXQIS972s78ReS0vsPE_4QohUykAO5_ctfrOgfCjAPG3esKMgqDFMMvn1tXCg5x6BekasC36chs7Zg7XlGPQ7Czc4NRVniDHpoamvJc6iNXnyth68VTcwgwwQ-8pmoXbwyo8hCCYLq1Iz5FSv3aVaIzYDXgIEHAfi30F1uyaBtq902Hj9XLhU',
      color: 'bg-primary-fixed',
    },
    {
      title: 'Rent Collection',
      icon: <CreditCard size={32} />,
      desc: 'Experience seamless cash flow with our automated, frictionless payment systems designed for modern tenants and sophisticated owners.',
      features: [
        'Multiple digital payment gateways',
        'Automated late fee enforcement and notifications',
        'Direct owner disbursements within 48 hours',
      ],
      img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAs2s8A1HESVdn18AhFH1b2scL_py_YcZMc5j1JzvAUcy1Yv1cWiZcbFwvPt8HYP3OOuY8Y4cDGXvfpab8c0zsXxhI_Wbqff_FMw2dWqoLjJlrhefGaikNJnsw6uMaT7K7hHyBaWPqF56ZDBO61RaiUxD25IPn-51eDR4Dcatr4TKhR0ZVPBYRPlpWCVx724GLs78tw1LrN5tVr8KzXMS5ItS_n35FoSLGCQTCL61J-eLJz6WPHaBzp7X0yD01NjYc7OThbYaUoNCk',
      color: 'bg-secondary-fixed/50',
    },
    {
      title: 'Maintenance & Repairs',
      icon: <Hammer size={32} />,
      desc: 'Protect your asset\'s value with proactive care and our vetted network of master craftsmen. We handle everything from minor repairs to major renovations.',
      features: [
        '24/7 emergency response dispatch',
        'Quarterly preventative maintenance inspections',
        'Pre-vetted premium contractor network',
      ],
      img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB1TK98dj2xeCIULlKZVvGS7iNPKG4ea8KWAJCNEGCis6W9x4VL59U8tMZcuITCV716fs-muthCtWgN_3mD_tgyMIDdurNQf9E11sK8eGQFnMYrEkk39eaxTQ3xlnwzOe1LEyqdytufZE8Ccmu6E6JwlEP_7pgBpq54MlLjyysDOlOAf9b_1GhrwFaPIr-Vjsh0orHgRb2xACtnyBcY5r2fDB1PiR-Ir0TFOH4Y1-57XvwerAUBDoe0Xp9y_xHjMtF2g5GwdGD64s8',
      color: 'bg-slate-200 dark:bg-slate-800',
    },
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <header className="relative h-[50vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAYZwU_Zd8Z4QtC74lhep-E26Ig29VDe4PWVFDscqwkNN4vOmxw-JGBhJs2gyP2jAncS-8nwmJw58Os8O8-udno7boOUuJN2PvYPwalOLtCfb2VQwK-AqM3Uf2chOsivlppx1dMqMlHN3JBAJMDSlVaPmWmZ687ukKrRYRWl0Sf8B0JIDmIhb9Jvvw_-d6ZMk3bCojbt_l4qewSdy6UZbedl2xQHVgdv6iJED_FDr7inziUvMfhG9loPRVUftBTCHHKf1JjOS401LU"
            alt="Services background"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-primary/60 dark:bg-slate-950/70 backdrop-brightness-75"></div>
        </div>
        <div className="relative z-10 text-center px-6 max-w-4xl">
          <h1 className="text-5xl md:text-7xl font-extrabold text-white font-headline tracking-tight mb-6 dark:font-serif dark:italic">
            Our Services
          </h1>
          <p className="text-xl md:text-2xl text-white/90 font-light max-w-2xl mx-auto leading-relaxed">
            Elevating property management through intentional design and elite concierge care.
          </p>
        </div>
      </header>

      {/* Service Breakdown */}
      <main className="py-24 px-6 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto space-y-32">
          {services.map((service, i) => (
            <section key={i} className={`grid grid-cols-1 lg:grid-cols-2 gap-16 items-center ${i % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
              <div className={i % 2 !== 0 ? 'lg:order-2' : 'lg:order-1'}>
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl ${service.color} mb-8 dark:text-primary`}>
                  {service.icon}
                </div>
                <h2 className="text-4xl font-bold font-headline text-primary dark:text-white mb-6 dark:font-serif">{service.title}</h2>
                <p className="text-lg text-slate-600 dark:text-slate-400 leading-relaxed mb-8">
                  {service.desc}
                </p>
                <ul className="space-y-4">
                  {service.features.map((f, j) => (
                    <li key={j} className="flex items-start gap-4">
                      <Verified className="text-secondary dark:text-secondary-fixed mt-1 shrink-0" size={20} />
                      <span className="text-primary dark:text-slate-200 font-medium">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className={`relative ${i % 2 !== 0 ? 'lg:order-1' : 'lg:order-2'}`}>
                <div className="absolute -inset-4 bg-secondary-fixed/20 rounded-3xl blur-2xl -z-10"></div>
                <img
                  src={service.img}
                  alt={service.title}
                  className="rounded-2xl shadow-2xl w-full h-[450px] object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </section>
          ))}
        </div>
      </main>

      {/* CTA Section */}
      <section className="py-24 bg-primary-container dark:bg-slate-900 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-secondary/5 -skew-x-12 transform translate-x-20"></div>
        <div className="max-w-5xl mx-auto px-6 text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold font-headline text-white mb-8 dark:font-serif dark:italic">Ready to experience the concierge difference?</h2>
          <p className="text-xl text-slate-300 mb-12 max-w-2xl mx-auto">
            Schedule a consultation with our property experts and discover how we can optimize your portfolio.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <Link to="/contact" className="w-full sm:w-auto px-10 py-4 bg-secondary-fixed text-primary font-bold rounded-xl shadow-lg hover:brightness-110 transition-all active:scale-95">
              Talk to an Expert
            </Link>
            <Link to="/contact" className="w-full sm:w-auto px-10 py-4 border-2 border-white/20 text-white font-bold rounded-xl hover:bg-white/5 transition-all">
              Get a Free Quote
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
