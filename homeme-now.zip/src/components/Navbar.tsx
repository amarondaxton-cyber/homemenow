import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Menu, X, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  const isHome = location.pathname === '/';
  const isTransparentOnHero = isHome && !isScrolled;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Properties', path: '/properties' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header
      className={cn(
        'fixed top-0 w-full z-50 transition-all duration-300',
        isScrolled
          ? 'bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl shadow-lg py-3'
          : 'bg-transparent py-5'
      )}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-8 flex justify-between items-center">
        <Link
          to="/"
          className={cn(
            "text-2xl font-extrabold tracking-tighter font-headline transition-colors duration-300",
            isTransparentOnHero ? "text-white" : "text-primary dark:text-white"
          )}
        >
          HomeMe Now
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={cn(
                'font-headline font-medium transition-colors duration-300',
                location.pathname === link.path
                  ? isTransparentOnHero 
                    ? 'text-white border-b-2 border-white' 
                    : 'text-secondary dark:text-secondary-fixed font-bold border-b-2 border-secondary dark:border-secondary-fixed'
                  : isTransparentOnHero
                    ? 'text-white/70 hover:text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:text-secondary dark:hover:text-secondary-fixed'
              )}
            >
              {link.name}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <button
            onClick={toggleTheme}
            className={cn(
              "p-2 rounded-full transition-colors",
              isTransparentOnHero 
                ? "text-white hover:bg-white/10" 
                : "text-primary dark:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            )}
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          </button>

          <Link
            to="/contact"
            className={cn(
              "hidden md:block px-6 py-2.5 rounded-lg font-bold transition-transform active:scale-95",
              isTransparentOnHero
                ? "bg-white text-primary hover:bg-white/90"
                : "bg-primary dark:bg-secondary-fixed text-white dark:text-primary"
            )}
          >
            Get Started
          </Link>

          <button
            className={cn(
              "md:hidden transition-colors",
              isTransparentOnHero ? "text-white" : "text-primary dark:text-white"
            )}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white dark:bg-slate-950 shadow-xl border-t dark:border-slate-800 p-6 flex flex-col gap-4 animate-in slide-in-from-top duration-300">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              onClick={() => setIsMenuOpen(false)}
              className={cn(
                'text-lg font-headline font-medium py-2',
                location.pathname === link.path
                  ? 'text-secondary dark:text-secondary-fixed font-bold'
                  : 'text-slate-600 dark:text-slate-400'
              )}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/contact"
            onClick={() => setIsMenuOpen(false)}
            className="bg-primary dark:bg-secondary-fixed text-white dark:text-primary px-6 py-3 rounded-lg font-bold text-center mt-2"
          >
            Get Started
          </Link>
        </div>
      )}
    </header>
  );
}
