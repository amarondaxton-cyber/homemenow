import React from 'react';
import { MapPin } from 'lucide-react';

interface PropertyCardProps {
  image: string;
  title: string;
  price: string;
  location: string;
  description: string;
  tag?: string;
  beds?: number;
  baths?: number;
  sqft?: string;
}

const PropertyCard: React.FC<PropertyCardProps> = ({
  image,
  title,
  price,
  location,
  description,
  tag,
  beds,
  baths,
  sqft,
}) => {
  return (
    <div className="group flex flex-col bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-100 dark:border-slate-800 shadow-xl transition-all duration-500 hover:-translate-y-2">
      <div className="relative h-80 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        {tag && (
          <div className="absolute top-4 left-4 backdrop-blur-md bg-secondary-container/90 dark:bg-secondary-fixed/90 text-on-secondary-container dark:text-primary px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider">
            {tag}
          </div>
        )}
      </div>
      <div className="p-8">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-2xl font-headline font-bold text-slate-900 dark:text-white mb-1">
              {title}
            </h3>
            <div className="flex items-center text-slate-500 dark:text-slate-400 text-sm">
              <MapPin size={14} className="mr-1" />
              {location}
            </div>
          </div>
          <div className="text-xl font-headline font-extrabold text-secondary dark:text-secondary-fixed">
            {price}
            {price.includes('/mo') ? '' : ''}
          </div>
        </div>
        <p className="text-slate-600 dark:text-slate-400 text-sm line-clamp-2 mb-6">
          {description}
        </p>
        {(beds || baths || sqft) && (
          <div className="grid grid-cols-3 gap-4 border-t border-slate-100 dark:border-slate-800 pt-6">
            {beds && (
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Beds</span>
                <span className="text-slate-900 dark:text-white font-bold">{beds}</span>
              </div>
            )}
            {baths && (
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Baths</span>
                <span className="text-slate-900 dark:text-white font-bold">{baths}</span>
              </div>
            )}
            {sqft && (
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1">Sq Ft</span>
                <span className="text-slate-900 dark:text-white font-bold">{sqft}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertyCard;
