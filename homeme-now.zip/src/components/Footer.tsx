import { Link } from 'react-router-dom';
import { Globe, Share2, MessageCircle, Phone, Mail, MapPin, Send } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-50 dark:bg-slate-900 w-full py-16 px-8 transition-colors duration-300">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="md:col-span-1">
          <Link to="/" className="text-2xl font-black text-slate-900 dark:text-slate-50 mb-4 block font-headline tracking-tighter">
            HomeMe Now
          </Link>
          <p className="text-slate-500 dark:text-slate-400 mb-6 text-sm leading-relaxed">
            Elevating the standard of property management through technology and touch. Precision, elegance, and reliability in every square foot.
          </p>
          <div className="flex gap-4">
            <Globe className="text-slate-500 hover:text-secondary cursor-pointer transition-colors" size={20} />
            <Share2 className="text-slate-500 hover:text-secondary cursor-pointer transition-colors" size={20} />
            <MessageCircle className="text-slate-500 hover:text-secondary cursor-pointer transition-colors" size={20} />
          </div>
        </div>

        <div>
          <h4 className="font-bold text-slate-900 dark:text-slate-50 mb-6 font-headline">Company</h4>
          <ul className="space-y-4">
            <li><Link to="/about" className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 text-sm transition-colors">About Us</Link></li>
            <li><Link to="/services" className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 text-sm transition-colors">Services</Link></li>
            <li><Link to="/properties" className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 text-sm transition-colors">Properties</Link></li>
            <li><Link to="/contact" className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 text-sm transition-colors">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-slate-900 dark:text-slate-50 mb-6 font-headline">Support</h4>
          <ul className="space-y-4">
            <li><Link to="/privacy" className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 text-sm transition-colors">Privacy Policy</Link></li>
            <li><Link to="/terms" className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 text-sm transition-colors">Terms of Service</Link></li>
            <li className="flex items-center gap-2 text-slate-500 dark:text-slate-400 text-sm"><Phone size={14} /> +1 234 567 890</li>
            <li className="flex items-center gap-2 text-slate-500 dark:text-slate-400 text-sm"><Mail size={14} /> concierge@homemenow.com</li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-slate-900 dark:text-slate-50 mb-6 font-headline">Newsletter</h4>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-4">Subscribe for quarterly real estate insights.</p>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="Email"
              className="bg-white dark:bg-slate-800 border-none rounded-md px-4 py-2 text-sm w-full focus:ring-2 focus:ring-secondary transition-all dark:text-white"
            />
            <button className="bg-primary dark:bg-secondary-fixed text-white dark:text-primary p-2 rounded-md transition-transform active:scale-95">
              <Send size={18} />
            </button>
          </div>
          <div className="mt-6 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Operating 24/7 for our clients</span>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-slate-200 dark:border-slate-800 text-center">
        <p className="text-slate-500 dark:text-slate-400 text-xs">© 2024 HomeMe Now. All rights reserved.</p>
      </div>
    </footer>
  );
}
